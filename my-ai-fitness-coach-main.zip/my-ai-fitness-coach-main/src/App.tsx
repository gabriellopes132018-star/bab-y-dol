import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import AppLayout from "@/components/AppLayout";
import DashboardPage from "@/pages/DashboardPage";
import AssessmentsPage from "@/pages/AssessmentsPage";
import DietPage from "@/pages/DietPage";
import WorkoutsPage from "@/pages/WorkoutsPage";
import AnalysisPage from "@/pages/AnalysisPage";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Sonner />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/avaliacoes" element={<AssessmentsPage />} />
            <Route path="/dieta" element={<DietPage />} />
            <Route path="/treinos" element={<WorkoutsPage />} />
            <Route path="/analise" element={<AnalysisPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
