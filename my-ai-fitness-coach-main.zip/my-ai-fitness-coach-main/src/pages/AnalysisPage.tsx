import { useState } from "react";
import { useAssessments } from "@/hooks/useAssessments";
import { Brain, Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export default function AnalysisPage() {
  const { assessments } = useAssessments();
  const [analysis, setAnalysis] = useState("");
  const [loading, setLoading] = useState(false);

  const runAnalysis = async () => {
    if (assessments.length === 0) { toast.error("Registre avaliações para análise"); return; }

    setLoading(true);
    try {
      const summary = assessments.slice(0, 10).map((a) =>
        `Data: ${a.created_at.slice(0, 10)}, Peso: ${a.weight}kg, Gordura: ${a.body_fat ?? "N/A"}%, Cintura: ${a.waist ?? "N/A"}cm`
      ).join("\n");

      const { data, error } = await supabase.functions.invoke("ai-analysis", {
        body: { assessments: summary },
      });

      if (error) throw error;
      setAnalysis(data.content);
    } catch (e) {
      toast.error("Erro na análise. Tente novamente.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-xl font-bold flex items-center gap-2">
        <Brain className="h-5 w-5 text-primary" />
        Análise Inteligente
      </h2>

      <div className="glass-card p-6 space-y-4">
        <p className="text-sm text-muted-foreground">
          A IA analisa suas {assessments.length} avaliações para detectar tendências, estagnação e gerar recomendações personalizadas.
        </p>
        <Button onClick={runAnalysis} disabled={loading || assessments.length === 0} className="gap-2">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          Analisar com IA
        </Button>
      </div>

      {analysis && (
        <div className="glass-card p-6 animate-slide-up">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Resultado da Análise
          </h3>
          <div className="prose prose-invert prose-sm max-w-none text-foreground">
            <ReactMarkdown>{analysis}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
}
