import { useState } from "react";
import { useAssessments, calculateBMI, bmiCategory } from "@/hooks/useAssessments";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

export default function AssessmentsPage() {
  const { assessments, loading, addAssessment, deleteAssessment } = useAssessments();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    weight: "", height: "", body_fat: "",
    chest: "", waist: "", hips: "", arms: "", thighs: "", notes: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.weight || !form.height) { toast.error("Peso e altura são obrigatórios"); return; }
    const err = await addAssessment({
      weight: +form.weight,
      height: +form.height,
      body_fat: form.body_fat ? +form.body_fat : null,
      chest: form.chest ? +form.chest : null,
      waist: form.waist ? +form.waist : null,
      hips: form.hips ? +form.hips : null,
      arms: form.arms ? +form.arms : null,
      thighs: form.thighs ? +form.thighs : null,
      notes: form.notes || null,
    });
    if (err) { toast.error("Erro ao salvar"); return; }
    toast.success("Avaliação salva!");
    setForm({ weight: "", height: "", body_fat: "", chest: "", waist: "", hips: "", arms: "", thighs: "", notes: "" });
    setShowForm(false);
  };

  const field = (label: string, key: string, placeholder: string, unit?: string) => (
    <div>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <div className="relative">
        <Input
          type="number"
          step="0.1"
          placeholder={placeholder}
          value={(form as any)[key]}
          onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          className="bg-muted border-border"
        />
        {unit && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">{unit}</span>}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Histórico de Avaliações</h2>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="h-4 w-4" />
          Nova Avaliação
        </Button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card p-6 space-y-4 animate-slide-up">
          <h3 className="font-semibold">Nova Avaliação Física</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {field("Peso *", "weight", "80", "kg")}
            {field("Altura *", "height", "175", "cm")}
            {field("Gordura", "body_fat", "15", "%")}
            {field("Peitoral", "chest", "100", "cm")}
            {field("Cintura", "waist", "80", "cm")}
            {field("Quadril", "hips", "95", "cm")}
            {field("Braços", "arms", "35", "cm")}
            {field("Coxas", "thighs", "55", "cm")}
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Observações</Label>
            <Input
              placeholder="Notas opcionais..."
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="bg-muted border-border"
            />
          </div>
          <div className="flex gap-2">
            <Button type="submit">Salvar</Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancelar</Button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-muted-foreground text-sm">Carregando...</p>
      ) : assessments.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <p className="text-muted-foreground">Nenhuma avaliação registrada ainda.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {assessments.map((a, i) => {
            const bmi = calculateBMI(a.weight, a.height);
            const prev = assessments[i + 1];
            const diff = prev ? +(a.weight - prev.weight).toFixed(1) : null;
            return (
              <div key={a.id} className="glass-card p-4 flex flex-col sm:flex-row sm:items-center gap-4 animate-slide-up">
                <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Data</p>
                    <p className="font-medium">{format(new Date(a.created_at), "dd/MM/yyyy", { locale: ptBR })}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Peso</p>
                    <p className="font-medium">{a.weight} kg</p>
                    {diff !== null && (
                      <span className={`text-xs ${diff <= 0 ? "text-success" : "text-destructive"}`}>
                        {diff > 0 ? "+" : ""}{diff} kg
                      </span>
                    )}
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">IMC</p>
                    <p className="font-medium">{bmi}</p>
                    <span className="text-xs text-muted-foreground">{bmiCategory(bmi)}</span>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Gordura</p>
                    <p className="font-medium">{a.body_fat ? `${a.body_fat}%` : "—"}</p>
                  </div>
                  {a.waist && (
                    <div>
                      <p className="text-xs text-muted-foreground">Cintura</p>
                      <p className="font-medium">{a.waist} cm</p>
                    </div>
                  )}
                  {a.chest && (
                    <div>
                      <p className="text-xs text-muted-foreground">Peitoral</p>
                      <p className="font-medium">{a.chest} cm</p>
                    </div>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => deleteAssessment(a.id)}
                  className="text-muted-foreground hover:text-destructive shrink-0"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
