import { useState } from "react";
import { useWorkouts, Exercise } from "@/hooks/useWorkouts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Dumbbell, X } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function WorkoutsPage() {
  const { workouts, loading, addWorkout, deleteWorkout } = useWorkouts();
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [exercises, setExercises] = useState<Exercise[]>([{ name: "", sets: 3, reps: 12 }]);

  const addExercise = () => setExercises([...exercises, { name: "", sets: 3, reps: 12 }]);
  const removeExercise = (i: number) => setExercises(exercises.filter((_, idx) => idx !== i));
  const updateExercise = (i: number, field: keyof Exercise, value: string | number) => {
    const updated = [...exercises];
    (updated[i] as any)[field] = value;
    setExercises(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) { toast.error("Nome do treino obrigatório"); return; }
    const validExercises = exercises.filter((ex) => ex.name.trim());
    if (validExercises.length === 0) { toast.error("Adicione pelo menos um exercício"); return; }
    const err = await addWorkout({ name, exercises: validExercises });
    if (err) { toast.error("Erro ao salvar"); return; }
    toast.success("Treino salvo!");
    setName("");
    setExercises([{ name: "", sets: 3, reps: 12 }]);
    setShowForm(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Dumbbell className="h-5 w-5 text-primary" />
          Meus Treinos
        </h2>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Treino
        </Button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card p-6 space-y-4 animate-slide-up">
          <div>
            <Label className="text-xs text-muted-foreground">Nome do Treino</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Treino A - Peito/Tríceps"
              className="bg-muted border-border"
            />
          </div>

          <div className="space-y-3">
            <Label className="text-xs text-muted-foreground">Exercícios</Label>
            {exercises.map((ex, i) => (
              <div key={i} className="flex items-center gap-2">
                <Input
                  placeholder="Nome do exercício"
                  value={ex.name}
                  onChange={(e) => updateExercise(i, "name", e.target.value)}
                  className="flex-1 bg-muted border-border"
                />
                <Input
                  type="number"
                  value={ex.sets}
                  onChange={(e) => updateExercise(i, "sets", +e.target.value)}
                  className="w-16 bg-muted border-border text-center"
                  placeholder="Séries"
                />
                <span className="text-xs text-muted-foreground">×</span>
                <Input
                  type="number"
                  value={ex.reps}
                  onChange={(e) => updateExercise(i, "reps", +e.target.value)}
                  className="w-16 bg-muted border-border text-center"
                  placeholder="Reps"
                />
                {exercises.length > 1 && (
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeExercise(i)}>
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button type="button" variant="ghost" onClick={addExercise} className="text-sm gap-1">
              <Plus className="h-3 w-3" /> Adicionar exercício
            </Button>
          </div>

          <div className="flex gap-2">
            <Button type="submit">Salvar Treino</Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancelar</Button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-muted-foreground text-sm">Carregando...</p>
      ) : workouts.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Dumbbell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Nenhum treino registrado.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {workouts.map((w) => (
            <div key={w.id} className="glass-card p-5 space-y-3 animate-slide-up">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">{w.name}</h3>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(w.created_at), "dd/MM/yyyy", { locale: ptBR })}
                  </p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => deleteWorkout(w.id)} className="text-muted-foreground hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-1">
                {w.exercises.map((ex, i) => (
                  <div key={i} className="flex items-center justify-between text-sm py-1 border-b border-border/50 last:border-0">
                    <span>{ex.name}</span>
                    <span className="text-muted-foreground">{ex.sets} × {ex.reps}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
