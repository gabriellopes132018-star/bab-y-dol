import { Scale, Activity, Percent, TrendingUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import MetricCard from "@/components/MetricCard";
import { useAssessments, calculateBMI, bmiCategory } from "@/hooks/useAssessments";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useAIAnalysis } from "@/hooks/useAIAnalysis";
import { Skeleton } from "@/components/ui/skeleton";

export default function DashboardPage() {
  const { assessments, loading } = useAssessments();
  const { insight, score, loading: aiLoading } = useAIAnalysis(assessments);

  const latest = assessments[0];
  const previous = assessments[1];

  const bmi = latest ? calculateBMI(latest.weight, latest.height) : 0;
  const weightTrend = latest && previous ? +((latest.weight - previous.weight) / previous.weight * 100).toFixed(1) : 0;
  const fatTrend = latest?.body_fat && previous?.body_fat ? +((latest.body_fat - previous.body_fat) / previous.body_fat * 100).toFixed(1) : 0;

  const chartData = [...assessments].reverse().map((a) => ({
    date: format(new Date(a.created_at), "dd/MM", { locale: ptBR }),
    peso: a.weight,
    gordura: a.body_fat ?? undefined,
  }));

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Peso Atual"
          value={latest ? `${latest.weight} kg` : "—"}
          icon={Scale}
          trend={weightTrend ? { value: -weightTrend, label: "vs anterior" } : undefined}
        />
        <MetricCard
          title="IMC"
          value={latest ? bmi : "—"}
          subtitle={latest ? bmiCategory(bmi) : undefined}
          icon={Activity}
        />
        <MetricCard
          title="Gordura Corporal"
          value={latest?.body_fat ? `${latest.body_fat}%` : "—"}
          icon={Percent}
          trend={fatTrend ? { value: -fatTrend, label: "vs anterior" } : undefined}
        />
        <MetricCard
          title="Score de Progresso"
          value={score !== null ? `${score}/100` : "—"}
          subtitle={aiLoading ? "Analisando..." : "Powered by IA"}
          icon={TrendingUp}
        />
      </div>

      {/* AI Insight */}
      {insight && (
        <div className="glass-card p-5 border-l-4 border-primary animate-slide-up">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold text-primary">Insight da IA</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">{insight}</p>
        </div>
      )}

      {/* Charts */}
      {chartData.length > 1 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="glass-card p-5 animate-slide-up">
            <h3 className="text-sm font-semibold mb-4">Evolução de Peso</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 14% 18%)" />
                <XAxis dataKey="date" stroke="hsl(215 15% 55%)" fontSize={12} />
                <YAxis stroke="hsl(215 15% 55%)" fontSize={12} />
                <Tooltip
                  contentStyle={{ background: "hsl(220 18% 10%)", border: "1px solid hsl(220 14% 18%)", borderRadius: "8px" }}
                  labelStyle={{ color: "hsl(210 20% 95%)" }}
                />
                <Line type="monotone" dataKey="peso" stroke="hsl(152 60% 48%)" strokeWidth={2} dot={{ fill: "hsl(152 60% 48%)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="glass-card p-5 animate-slide-up">
            <h3 className="text-sm font-semibold mb-4">Evolução de Gordura (%)</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData.filter(d => d.gordura !== undefined)}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 14% 18%)" />
                <XAxis dataKey="date" stroke="hsl(215 15% 55%)" fontSize={12} />
                <YAxis stroke="hsl(215 15% 55%)" fontSize={12} />
                <Tooltip
                  contentStyle={{ background: "hsl(220 18% 10%)", border: "1px solid hsl(220 14% 18%)", borderRadius: "8px" }}
                  labelStyle={{ color: "hsl(210 20% 95%)" }}
                />
                <Line type="monotone" dataKey="gordura" stroke="hsl(38 92% 55%)" strokeWidth={2} dot={{ fill: "hsl(38 92% 55%)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {assessments.length === 0 && (
        <div className="glass-card p-12 text-center animate-slide-up">
          <Activity className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Nenhuma avaliação registrada</h3>
          <p className="text-sm text-muted-foreground">Vá em "Avaliações" para registrar sua primeira avaliação física.</p>
        </div>
      )}
    </div>
  );
}
