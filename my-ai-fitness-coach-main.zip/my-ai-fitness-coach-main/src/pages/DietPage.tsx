import { useState } from "react";
import { useAssessments } from "@/hooks/useAssessments";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Utensils, Sparkles, Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export default function DietPage() {
  const { assessments } = useAssessments();
  const latest = assessments[0];

  const [age, setAge] = useState("");
  const [goal, setGoal] = useState("emagrecer");
  const [activityLevel, setActivityLevel] = useState("moderado");
  const [diet, setDiet] = useState("");
  const [loading, setLoading] = useState(false);

  const generateDiet = async (adjust = false) => {
    if (!latest) { toast.error("Registre uma avaliação primeiro"); return; }
    if (!age) { toast.error("Informe sua idade"); return; }

    setLoading(true);
    try {
      const prompt = adjust
        ? `Ajuste a dieta anterior considerando: ${diet}\n\nDados: peso ${latest.weight}kg, altura ${latest.height}cm, idade ${age}, gordura ${latest.body_fat ?? "não informado"}%, objetivo: ${goal}, nível atividade: ${activityLevel}. Faça ajustes para melhorar resultados.`
        : `Gere um plano alimentar completo para: peso ${latest.weight}kg, altura ${latest.height}cm, idade ${age} anos, gordura corporal ${latest.body_fat ?? "não informado"}%, objetivo: ${goal}, nível de atividade: ${activityLevel}.`;

      const { data, error } = await supabase.functions.invoke("ai-diet", {
        body: { prompt },
      });

      if (error) throw error;
      setDiet(data.content);
    } catch (e: any) {
      toast.error("Erro ao gerar dieta. Tente novamente.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-xl font-bold flex items-center gap-2">
        <Utensils className="h-5 w-5 text-primary" />
        Gerador de Dieta com IA
      </h2>

      <div className="glass-card p-6 space-y-4">
        <h3 className="font-semibold">Seus dados</h3>
        {latest ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div>
              <p className="text-xs text-muted-foreground">Peso</p>
              <p className="font-medium">{latest.weight} kg</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Altura</p>
              <p className="font-medium">{latest.height} cm</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Gordura</p>
              <p className="font-medium">{latest.body_fat ? `${latest.body_fat}%` : "—"}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Idade *</Label>
              <Input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="25"
                className="bg-muted border-border mt-1"
              />
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Registre uma avaliação para usar o gerador de dieta.</p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs text-muted-foreground">Objetivo</Label>
            <Select value={goal} onValueChange={setGoal}>
              <SelectTrigger className="bg-muted border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="emagrecer">Emagrecer</SelectItem>
                <SelectItem value="ganhar massa">Ganhar Massa</SelectItem>
                <SelectItem value="manter peso">Manter Peso</SelectItem>
                <SelectItem value="definicao">Definição Muscular</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Nível de Atividade</Label>
            <Select value={activityLevel} onValueChange={setActivityLevel}>
              <SelectTrigger className="bg-muted border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentario">Sedentário</SelectItem>
                <SelectItem value="leve">Leve (1-2x/semana)</SelectItem>
                <SelectItem value="moderado">Moderado (3-4x/semana)</SelectItem>
                <SelectItem value="intenso">Intenso (5-6x/semana)</SelectItem>
                <SelectItem value="muito intenso">Muito Intenso (diário)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-3">
          <Button onClick={() => generateDiet(false)} disabled={loading} className="gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            Gerar Dieta com IA
          </Button>
          {diet && (
            <Button onClick={() => generateDiet(true)} disabled={loading} variant="secondary" className="gap-2">
              Ajustar Dieta
            </Button>
          )}
        </div>
      </div>

      {diet && (
        <div className="glass-card p-6 animate-slide-up">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Plano Alimentar Gerado
          </h3>
          <div className="prose prose-invert prose-sm max-w-none text-foreground">
            <ReactMarkdown>{diet}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
}
