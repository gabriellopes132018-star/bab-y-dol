import { useState, useEffect } from "react";
import { Assessment } from "./useAssessments";
import { supabase } from "@/lib/supabase";

export function useAIAnalysis(assessments: Assessment[]) {
  const [insight, setInsight] = useState<string | null>(null);
  const [score, setScore] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (assessments.length < 2) return;

    const analyze = async () => {
      setLoading(true);
      try {
        const summary = assessments.slice(0, 5).map((a) =>
          `${a.created_at.slice(0, 10)}: ${a.weight}kg, gordura ${a.body_fat ?? "N/A"}%`
        ).join("; ");

        const { data, error } = await supabase.functions.invoke("ai-insight", {
          body: { summary },
        });

        if (error) throw error;
        setInsight(data.insight);
        setScore(data.score);
      } catch {
        // Silently fail for dashboard insight
      } finally {
        setLoading(false);
      }
    };

    analyze();
  }, [assessments]);

  return { insight, score, loading };
}
