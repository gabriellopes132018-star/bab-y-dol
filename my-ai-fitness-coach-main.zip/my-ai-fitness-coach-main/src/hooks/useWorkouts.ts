import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";

export interface Exercise {
  name: string;
  sets: number;
  reps: number;
}

export interface Workout {
  id: string;
  name: string;
  exercises: Exercise[];
  created_at: string;
}

export function useWorkouts() {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("workouts")
      .select("*")
      .order("created_at", { ascending: false });
    setWorkouts((data ?? []).map((d: any) => ({ ...d, exercises: d.exercises as Exercise[] })));
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const addWorkout = async (w: { name: string; exercises: Exercise[] }) => {
    const { error } = await supabase.from("workouts").insert([{ name: w.name, exercises: w.exercises as any }]);
    if (!error) await fetch();
    return error;
  };

  const deleteWorkout = async (id: string) => {
    await supabase.from("workouts").delete().eq("id", id);
    await fetch();
  };

  return { workouts, loading, addWorkout, deleteWorkout, refetch: fetch };
}
