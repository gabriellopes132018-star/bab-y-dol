import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";

export interface Assessment {
  id: string;
  weight: number;
  height: number;
  body_fat: number | null;
  chest: number | null;
  waist: number | null;
  hips: number | null;
  arms: number | null;
  thighs: number | null;
  notes: string | null;
  created_at: string;
}

export function calculateBMI(weight: number, heightCm: number) {
  const heightM = heightCm / 100;
  return +(weight / (heightM * heightM)).toFixed(1);
}

export function bmiCategory(bmi: number) {
  if (bmi < 18.5) return "Abaixo do peso";
  if (bmi < 25) return "Peso normal";
  if (bmi < 30) return "Sobrepeso";
  return "Obesidade";
}

export function useAssessments() {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("assessments")
      .select("*")
      .order("created_at", { ascending: false });
    setAssessments(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const addAssessment = async (a: Omit<Assessment, "id" | "created_at">) => {
    const { error } = await supabase.from("assessments").insert(a);
    if (!error) await fetch();
    return error;
  };

  const deleteAssessment = async (id: string) => {
    await supabase.from("assessments").delete().eq("id", id);
    await fetch();
  };

  return { assessments, loading, addAssessment, deleteAssessment, refetch: fetch };
}
