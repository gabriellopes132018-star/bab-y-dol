import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { summary } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: `Você analisa dados fitness. Responda APENAS com JSON válido (sem markdown), no formato:
{"insight": "frase curta e motivadora sobre a evolução do usuário em português", "score": 75}
O score é de 0 a 100 baseado no progresso. A frase deve ter no máximo 2 linhas.`,
          },
          { role: "user", content: `Dados recentes: ${summary}` },
        ],
      }),
    });

    if (!response.ok) throw new Error("AI error");

    const data = await response.json();
    const text = data.choices?.[0]?.message?.content ?? '{"insight":"Continue registrando suas avaliações","score":50}';
    
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = { insight: text.slice(0, 200), score: 50 };
    }

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-insight error:", e);
    return new Response(JSON.stringify({ insight: null, score: null }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
